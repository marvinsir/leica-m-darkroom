# Leica M Darkroom

An offline Android photo developer for ARM64 phones running Android 10 or later. Package ID is `org.privatedarkroom.leicam`.

## Interface

The app supports English, Traditional Chinese, Simplified Chinese and Japanese. It follows the device language by default. On Android 13 and later, its language can also be set in the system's App Languages settings.

Latin control labels and numerals use [F5.6](https://www.dotcolon.net/fonts/f5_6/) 0.110 by Sora Sagano, distributed under the SIL Open Font License 1.1 in `app/assets/licenses/F5.6-OFL.txt`. Android supplies the Chinese and Japanese glyphs and symbols absent from F5.6, including the percent sign.

## Build

Use JDK 17, Android SDK platform 36 and Build Tools 35 or later, and the ONNX Runtime Android 1.22.0 AAR (`com.microsoft.onnxruntime:onnxruntime-android:1.22.0`). The packaged ONNX models and LUTs are ready to use.

```sh
export JAVA_HOME=/path/to/jdk-17
export ANDROID_BUILD_TOOLS=/path/to/android-sdk/build-tools/35.0.0
export ANDROID_JAR=/path/to/android-sdk/platforms/android-36/android.jar
export ORT_AAR=/path/to/onnxruntime-android-1.22.0.aar
bash build-apk.sh
```

The signed ARM64 APK goes to the sibling `delivery` directory. The script generates a local signing key under `out/signing` the first time it runs. Keep the signing key from the first build if you intend to issue updates under the same package ID.

## Photo processing

- M9 Fast uses the heads from the supplied distilled model and renders the result row by row.
- M9 High uses the 560×432 mobile StyleTrans graph. M9 Full uses the native 1120×864 graph and a fixed daylight table from the supplied snapshot BIN.
- M9 Daylight LUT uses the fixed daylight table from the supplied preview BIN. Both tables use the common scene at lux index 275 and 5500 K from the OffLineM9 reference.
- MONOPAN applies the normalized published RGB channel mix to an sRGB photo.
- Vignetting is a separate adjustable smooth edge-darkening effect.

The Android photo picker provides the source URI. Android MediaStore publishes a new JPEG or PNG to `Pictures/Leica M Darkroom`. The decoder retains up to 16 megapixels and caps the long edge at 8192 pixels.

The full-size graph and fixed tables can be regenerated with `python prepare_assets.py /path/to/asset/files`. This requires the Python ONNX package and the supplied source ONNX and M9 BINs.
