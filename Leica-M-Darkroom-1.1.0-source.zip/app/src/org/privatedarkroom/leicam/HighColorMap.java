package org.privatedarkroom.leicam;

/** Transfers the model's spatial colour differences without upscaling its generated pixels. */
final class HighColorMap {
    static final int WIDTH = 560;
    static final int HEIGHT = 432;
    private static final int BORDER = 24;
    final int modelWidth;
    final int modelHeight;
    private final int plane;
    private final boolean portrait;
    final int fitWidth;
    final int fitHeight;
    final int left;
    final int top;
    private final int[] xOffsets;
    private final int[] yOffsets;
    private final float[] xFractions;
    private final float[] yFractions;

    HighColorMap(int width, int height, int modelWidth, int modelHeight) {
        this.modelWidth = modelWidth;
        this.modelHeight = modelHeight;
        plane = modelWidth * modelHeight;
        int border = modelWidth == WIDTH ? BORDER : BORDER * 2;
        portrait = height > width;
        int viewWidth = portrait ? height : width;
        int viewHeight = portrait ? width : height;
        float scale = Math.min((modelWidth - border * 2f) / viewWidth, (modelHeight - border * 2f) / viewHeight);
        fitWidth = Math.max(1, Math.round(viewWidth * scale));
        fitHeight = Math.max(1, Math.round(viewHeight * scale));
        left = (modelWidth - fitWidth) / 2;
        top = (modelHeight - fitHeight) / 2;
        xOffsets = new int[width];
        yOffsets = new int[height];
        xFractions = new float[width];
        yFractions = new float[height];
        for (int x = 0; x < width; x++) {
            float p = sample(x, width, portrait ? fitHeight : fitWidth, portrait ? top : left);
            xOffsets[x] = (int) p * (portrait ? modelWidth : 1);
            xFractions[x] = p - (int) p;
        }
        for (int y = 0; y < height; y++) {
            float p = sample(portrait ? height - 1 - y : y, height,
                    portrait ? fitWidth : fitHeight, portrait ? left : top);
            yOffsets[y] = (int) p * (portrait ? 1 : modelWidth);
            yFractions[y] = p - (int) p;
        }
    }

    private static float sample(int at, int limit, int fitted, int offset) {
        return offset + Math.max(0f, Math.min(fitted - 1f, (at + 0.5f) * fitted / limit - 0.5f));
    }

    private static int reflect(int at, int length) {
        int period = 2 * length;
        int pos = Math.floorMod(at, period);
        return pos < length ? pos : period - 1 - pos;
    }

    int guideWidth() { return portrait ? fitHeight : fitWidth; }

    int guideHeight() { return portrait ? fitWidth : fitHeight; }

    float[] inputs(int[] guide) {
        float[] result = new float[3 * plane];
        for (int y = 0; y < modelHeight; y++) {
            int uy = reflect(y - top, fitHeight);
            for (int x = 0; x < modelWidth; x++) {
                int ux = reflect(x - left, fitWidth);
                int i = y * modelWidth + x;
                int p = portrait ? guide[(fitWidth - 1 - ux) * fitHeight + uy]
                                 : guide[uy * fitWidth + ux];
                result[i] = (((p >>> 16) & 255) - 128f) / 127.5f;
                result[plane + i] = (((p >>> 8) & 255) - 128f) / 127.5f;
                result[2 * plane + i] = ((p & 255) - 128f) / 127.5f;
            }
        }
        return result;
    }

    void setDelta(float[] normalizedInput, float[] modelOutput) {
        if (normalizedInput.length != 3 * plane || modelOutput.length != normalizedInput.length) {
            throw new IllegalArgumentException("Unexpected M9 High output shape");
        }
        for (int i = 0; i < normalizedInput.length; i++) {
            float value = modelOutput[i] * 127.5f + 128f;
            float original = normalizedInput[i] * 127.5f + 128f;
            modelOutput[i] = Float.isFinite(value)
                    ? Math.max(0f, Math.min(255f, value)) - original : 0f;
        }
    }

    void renderRow(int y, int[] row, float[] delta) {
        int vertical = yOffsets[y];
        float dy = yFractions[y];
        int alongX = portrait ? modelWidth : 1;
        int alongY = portrait ? 1 : modelWidth;
        for (int x = 0; x < row.length; x++) {
            int pixel = row[x];
            int p = vertical + xOffsets[x];
            float dx = xFractions[x];
            int color = pixel & 0xff000000;
            for (int c = 0; c < 3; c++, p += plane) {
                float a = delta[p] + (delta[p + alongX] - delta[p]) * dx;
                float b = delta[p + alongY] + (delta[p + alongX + alongY] - delta[p + alongY]) * dx;
                int shift = 16 - 8 * c;
                int value = Math.round(((pixel >>> shift) & 255) + a + (b - a) * dy);
                color |= Math.max(0, Math.min(255, value)) << shift;
            }
            row[x] = color;
        }
    }
}
