package org.privatedarkroom.leicam;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.FloatBuffer;
import java.util.Collections;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtException;
import ai.onnxruntime.OrtSession;

final class M9Renderer implements AutoCloseable {
    private static final int GUIDE_SIDE = 256;
    private final AssetManager assets;
    private OrtSession session;

    M9Renderer(AssetManager assets) {
        this.assets = assets;
    }

    Bitmap render(Bitmap original) throws IOException, OrtException, InterruptedException {
        OrtEnvironment env = OrtEnvironment.getEnvironment();
        if (session == null) {
            try (OrtSession.SessionOptions options = new OrtSession.SessionOptions()) {
                options.setIntraOpNumThreads(2);
                options.setInterOpNumThreads(1);
                session = env.createSession(readModel(assets, "m9-heads.onnx"), options);
            }
        }

        int width = original.getWidth(), height = original.getHeight();
        Bitmap guide = guideFor(original);
        int gw = guide.getWidth(), gh = guide.getHeight();
        float[] input = new float[3 * gw * gh];
        try {
            int[] row = new int[gw];
            int plane = gw * gh;
            for (int y = 0; y < gh; y++) {
                guide.getPixels(row, 0, gw, 0, y, gw, 1);
                for (int x = 0; x < gw; x++) {
                    int p = row[x], i = y * gw + x;
                    input[i] = ((p >>> 16) & 255) * (1f / 255f);
                    input[plane + i] = ((p >>> 8) & 255) * (1f / 255f);
                    input[2 * plane + i] = (p & 255) * (1f / 255f);
                }
            }
        } finally {
            if (guide != original) guide.recycle();
        }

        ColorMap map;
        try (OnnxTensor low = OnnxTensor.createTensor(env, FloatBuffer.wrap(input), new long[]{1, 3, gh, gw});
             OrtSession.Result results = session.run(Collections.singletonMap("lowres", low))) {
            OnnxTensor grid = (OnnxTensor) results.get("grid").orElseThrow(IllegalStateException::new);
            OnnxTensor residual = (OnnxTensor) results.get("residual").orElseThrow(IllegalStateException::new);
            long[] g = grid.getInfo().getShape(), r = residual.getInfo().getShape();
            if (g.length != 4 || r.length != 4 || g[0] != 1 || r[0] != 1 || g[1] != 12 || r[1] != 3) {
                throw new IOException("模型輸出尺寸不符");
            }
            map = new ColorMap(copy(grid), (int) g[3], (int) g[2], copy(residual), (int) r[3], (int) r[2], width, height);
        }

        int[] row = new int[width];
        for (int y = 0; y < height; y++) {
            if (Thread.currentThread().isInterrupted()) throw new InterruptedException();
            original.getPixels(row, 0, width, 0, y, width, 1);
            map.renderRow(y, row);
            original.setPixels(row, 0, width, 0, y, width, 1);
        }
        return original;
    }

    static float[] copy(OnnxTensor tensor) {
        FloatBuffer buffer = tensor.getFloatBuffer();
        float[] floats = new float[buffer.remaining()];
        buffer.get(floats);
        return floats;
    }

    static Bitmap resizeTo(Bitmap source, int maxSide) {
        int w = source.getWidth(), h = source.getHeight();
        int longest = Math.max(w, h);
        if (longest <= maxSide) return source;
        float factor = (float) maxSide / longest;
        return Bitmap.createScaledBitmap(source, Math.max(1, Math.round(w * factor)),
                Math.max(1, Math.round(h * factor)), true);
    }

    private static Bitmap guideFor(Bitmap bitmap) {
        Bitmap guide = bitmap;
        while (Math.max(guide.getWidth(), guide.getHeight()) > GUIDE_SIDE * 2) {
            int half = Math.max(guide.getWidth(), guide.getHeight()) / 2;
            Bitmap reduced = resizeTo(guide, half);
            if (guide != bitmap) guide.recycle();
            guide = reduced;
        }
        Bitmap result = resizeTo(guide, GUIDE_SIDE);
        if (guide != bitmap && guide != result) guide.recycle();
        return result;
    }

    static byte[] readModel(AssetManager assets, String name) throws IOException {
        try (InputStream input = assets.open(name);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[16_384];
            for (int n; (n = input.read(chunk)) != -1; ) output.write(chunk, 0, n);
            return output.toByteArray();
        }
    }

    @Override public void close() {
        if (session != null) {
            try {
                session.close();
            } catch (OrtException ignored) {
                // No additional work is pending once the activity is closed.
            }
        }
    }
}
