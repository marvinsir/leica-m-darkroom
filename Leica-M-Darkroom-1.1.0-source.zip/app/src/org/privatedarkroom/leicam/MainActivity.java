package org.privatedarkroom.leicam;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorSpace;
import android.graphics.ImageDecoder;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Size;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static org.privatedarkroom.leicam.DarkroomRenderer.Mode;

public final class MainActivity extends Activity {
    private static final int PICK_PHOTO = 100;
    private static final int PIXEL_LIMIT = 16_000_000;
    private static final int SIDE_LIMIT = 8192;
    private static final int PREVIEW_SIDE = 1200;
    private static final String ALBUM = "Leica M Darkroom";
    private static final int BACKGROUND = 0xff121212;
    private static final int PREVIEW_BACKGROUND = 0xff0c0c0c;
    private static final int PAPER = 0xfff4f0e7;
    private static final int DIM = 0xffb4aea3;
    private static final int RULE = 0xff615e59;
    private static final int ACCENT = 0xffdb3845;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Runnable previewUpdate = this::updateVignettePreview;
    private DarkroomRenderer renderer;
    private Rendered photo;
    private Bitmap shadedPreview;
    private int vignette;
    private int photoRequest;
    private int previewRequest;
    private boolean showingOriginal;
    private boolean busy;
    private Mode mode = Mode.QUICK;
    private Uri currentUri;
    private Typeface display;
    private Typeface displayBold;

    private ImageView image;
    private LinearLayout welcome;
    private TextView status;
    private TextView vignetteValue;
    private final Button[] modeButtons = new Button[Mode.values().length];
    private final View[] modeIndicators = new View[modeButtons.length];
    private SeekBar vignetteBar;
    private Button select;
    private Button compare;
    private Button save;
    private ProgressBar progress;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        renderer = new DarkroomRenderer(getAssets());
        display = getResources().getFont(R.font.f56_regular);
        displayBold = Typeface.create(display, Typeface.BOLD);
        if (state != null) {
            currentUri = state.getParcelable("photo");
            mode = Mode.values()[state.getInt("mode", 0)];
            vignette = state.getInt("vignette");
        }
        makeUi();
        refresh(false);
        if (currentUri != null) process(currentUri);
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        state.putParcelable("photo", currentUri);
        state.putInt("mode", mode.ordinal());
        state.putInt("vignette", vignette);
    }

    private void makeUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        LinearLayout body = column();
        body.setPadding(dp(14), dp(8), dp(14), dp(10));
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, dp(8), 0, dp(12));
        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.darkroom_icon);
        mark.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        header.addView(mark, new LinearLayout.LayoutParams(dp(58), dp(58)));
        TextView title = label(getString(R.string.wordmark), 22, PAPER);
        title.setTypeface(displayBold);
        title.setLetterSpacing(0.14f);
        title.setIncludeFontPadding(false);
        title.setLineSpacing(0, 0.91f);
        title.setContentDescription(getString(R.string.app_name));
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        body.addView(header);

        FrameLayout frame = new FrameLayout(this) {
            @Override protected void onMeasure(int widthSpec, int heightSpec) {
                int previewHeight = MeasureSpec.getMode(heightSpec) == MeasureSpec.EXACTLY
                        ? heightSpec : MeasureSpec.makeMeasureSpec(dp(200), MeasureSpec.EXACTLY);
                super.onMeasure(widthSpec, previewHeight);
            }
        };
        frame.setBackgroundColor(PREVIEW_BACKGROUND);
        image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setContentDescription(getString(R.string.photo_preview));
        frame.addView(image, new FrameLayout.LayoutParams(-1, -1));

        welcome = column();
        welcome.setGravity(Gravity.CENTER);
        welcome.setPadding(dp(18), dp(12), dp(18), dp(12));
        TextView prompt = label(getString(R.string.empty_title), 23, PAPER);
        prompt.setGravity(Gravity.CENTER);
        prompt.setTypeface(displayBold);
        welcome.addView(prompt);
        TextView sub = label(getString(R.string.empty_description), 14, DIM);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(6), 0, 0);
        welcome.addView(sub);
        frame.addView(welcome, new FrameLayout.LayoutParams(-1, -1));
        body.addView(frame, new LinearLayout.LayoutParams(-1, -2, 1f));
        addRule(body, 12);
        makeAdjustments(body);

        LinearLayout reading = new LinearLayout(this);
        reading.setGravity(Gravity.CENTER_VERTICAL);
        progress = new ProgressBar(this);
        progress.setIndeterminateTintList(ColorStateList.valueOf(ACCENT));
        reading.addView(progress, new LinearLayout.LayoutParams(dp(18), dp(18)));
        status = label("", 13, DIM);
        status.setPadding(dp(4), 0, 0, 0);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        reading.addView(status, new LinearLayout.LayoutParams(0, -2, 1f));
        body.addView(reading, new LinearLayout.LayoutParams(-1, -2));
        addRule(body, 8);

        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(0, dp(5), 0, 0);
        select = control(R.string.pick, false);
        select.setOnClickListener(v -> pickPhoto());
        compare = control(R.string.before, false);
        compare.setOnClickListener(v -> {
            showingOriginal = !showingOriginal;
            showPreview();
        });
        save = control(R.string.save, true);
        save.setOnClickListener(v -> savePhoto());
        addAction(actions, select, false);
        addAction(actions, compare, true);
        addAction(actions, save, true);
        body.addView(actions);
        setContentView(scroll);
        refreshModes();
    }

    private void makeAdjustments(LinearLayout body) {
        LinearLayout row = new LinearLayout(this);
        for (Mode chosen : Mode.values()) {
            FrameLayout tab = new FrameLayout(this);
            Button button = control(chosen.shortLabel, false);
            button.setContentDescription(getString(chosen.label));
            button.setOnClickListener(v -> {
                if (mode == chosen || busy) return;
                mode = chosen;
                refreshModes();
                if (currentUri != null) process(currentUri);
            });
            tab.addView(button, new FrameLayout.LayoutParams(-1, -1));
            View indicator = new View(this);
            indicator.setBackgroundColor(ACCENT);
            indicator.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            FrameLayout.LayoutParams indicatorParams = new FrameLayout.LayoutParams(
                    dp(24), dp(2), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            indicatorParams.bottomMargin = dp(3);
            tab.addView(indicator, indicatorParams);
            modeButtons[chosen.ordinal()] = button;
            modeIndicators[chosen.ordinal()] = indicator;
            row.addView(tab, new LinearLayout.LayoutParams(0, dp(48), 1f));
        }
        body.addView(row);

        LinearLayout slider = new LinearLayout(this);
        slider.setGravity(Gravity.CENTER_VERTICAL);
        TextView sliderLabel = label(getString(R.string.vignette), 15, PAPER);
        sliderLabel.setTypeface(display);
        sliderLabel.setPadding(dp(4), 0, 0, 0);
        slider.addView(sliderLabel);
        vignetteBar = new VignetteSlider();
        vignetteBar.setMax(100);
        vignetteBar.setProgress(vignette);
        vignetteBar.setKeyProgressIncrement(5);
        vignetteBar.setContentDescription(getString(R.string.vignette));
        slider.addView(vignetteBar, new LinearLayout.LayoutParams(0, dp(48), 1f));
        vignetteValue = label(formatVignette(), 16, PAPER);
        vignetteValue.setTypeface(display);
        vignetteValue.setMinWidth(dp(42));
        vignetteValue.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        slider.addView(vignetteValue, new LinearLayout.LayoutParams(-2, dp(48)));
        body.addView(slider);
        vignetteBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                vignette = value;
                vignetteValue.setText(formatVignette());
                previewRequest++;
                bar.removeCallbacks(previewUpdate);
                bar.postDelayed(previewUpdate, 65);
            }

            @Override public void onStartTrackingTouch(SeekBar bar) {}

            @Override public void onStopTrackingTouch(SeekBar bar) {
                bar.removeCallbacks(previewUpdate);
                updateVignettePreview();
            }
        });
    }

    private void refreshModes() {
        for (int i = 0; i < modeButtons.length; i++) {
            boolean selected = i == mode.ordinal();
            Button button = modeButtons[i];
            button.setSelected(selected);
            button.setTypeface(selected ? displayBold : display);
            button.setTextColor(selected ? PAPER : DIM);
            modeIndicators[i].setVisibility(selected ? View.VISIBLE : View.INVISIBLE);
        }
    }

    private final class VignetteSlider extends SeekBar {
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);

        VignetteSlider() {
            super(MainActivity.this);
            setPadding(dp(12), 0, dp(12), 0);
            setProgressDrawable(new ColorDrawable(0x00000000));
            setSplitTrack(false);
            GradientDrawable thumb = new GradientDrawable();
            thumb.setShape(GradientDrawable.OVAL);
            thumb.setColor(PAPER);
            thumb.setSize(dp(12), dp(12));
            setThumb(thumb);
            setThumbTintList(ColorStateList.valueOf(PAPER));
        }

        @Override protected synchronized void onDraw(Canvas canvas) {
            float start = getPaddingLeft();
            float end = getWidth() - getPaddingRight();
            float middle = getHeight() / 2f;
            track.setStrokeWidth(dp(1));
            track.setColor(DIM);
            canvas.drawLine(start, middle, end, middle, track);
            track.setColor(RULE);
            for (int tick = 0; tick <= 10; tick++) {
                float x = start + (end - start) * tick / 10f;
                canvas.drawLine(x, middle - dp(3), x, middle + dp(3), track);
            }
            super.onDraw(canvas);
        }
    }

    private String formatVignette() {
        return getString(R.string.percentage, vignette);
    }

    private LinearLayout column() {
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        return view;
    }

    private void addAction(LinearLayout row, Button button, boolean gap) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(48), 1f);
        if (gap) params.setMarginStart(dp(5));
        row.addView(button, params);
    }

    private void addRule(LinearLayout parent, int topMargin) {
        View rule = new View(this);
        rule.setBackgroundColor(RULE);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(1));
        params.topMargin = dp(topMargin);
        parent.addView(rule, params);
    }

    private Button control(int text, boolean outlined) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(text);
        button.setTypeface(displayBold);
        button.setLetterSpacing(0.065f);
        button.setMaxLines(2);
        button.setIncludeFontPadding(false);
        button.setAutoSizeTextTypeUniformWithConfiguration(10, 16, 1, TypedValue.COMPLEX_UNIT_SP);
        button.setTextColor(PAPER);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(BACKGROUND);
        if (outlined) shape.setStroke(dp(1), PAPER);
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(0x2effffff), shape, null));
        button.setPadding(dp(3), 0, dp(3), 0);
        button.setStateListAnimator(null);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        return button;
    }

    private TextView label(String text, int size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void pickPhoto() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        try {
            startActivityForResult(pick, PICK_PHOTO);
        } catch (ActivityNotFoundException error) {
            status.setText(R.string.no_picker);
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_PHOTO && result == RESULT_OK && data != null && data.getData() != null) {
            process(data.getData());
        }
    }

    private static final class Rendered {
        final Bitmap before;
        final Bitmap after;
        final Bitmap output;

        Rendered(Bitmap before, Bitmap after, Bitmap output) {
            this.before = before;
            this.after = after;
            this.output = output;
        }
    }

    private void process(Uri uri) {
        currentUri = uri;
        int request = ++photoRequest;
        previewRequest++;
        vignetteBar.removeCallbacks(previewUpdate);
        if (photo != null) photo.output.recycle();
        photo = null;
        shadedPreview = null;
        showingOriginal = false;
        showPreview();
        Mode chosen = mode;
        status.setText(getString(R.string.processing, getString(chosen.label)));
        refresh(true);
        worker.execute(() -> {
            try {
                Rendered result = render(uri, chosen);
                runOnUiThread(() -> {
                    if (isDestroyed() || request != photoRequest) {
                        result.output.recycle();
                        return;
                    }
                    photo = result;
                    showPreview();
                    status.setText(getString(R.string.image_size, result.output.getWidth(), result.output.getHeight()));
                    refresh(false);
                    updateVignettePreview();
                });
            } catch (OutOfMemoryError error) {
                showError(request, chosen == Mode.FULL ? R.string.full_memory_error : R.string.memory_error);
            } catch (Exception | LinkageError error) {
                android.util.Log.e("LeicaMDarkroom", "Could not process photo", error);
                showError(request, chosen == Mode.FULL ? R.string.full_render_error : R.string.render_error);
            }
        });
    }

    private Rendered render(Uri uri, Mode chosen) throws Exception {
        ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
        Bitmap output = ImageDecoder.decodeBitmap(source, (decoder, info, ignored) -> {
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            decoder.setMutableRequired(true);
            decoder.setTargetColorSpace(ColorSpace.get(ColorSpace.Named.SRGB));
            Size size = info.getSize();
            int width = size.getWidth(), height = size.getHeight();
            double areaScale = Math.sqrt((double) PIXEL_LIMIT / ((long) width * height));
            double sideScale = (double) SIDE_LIMIT / Math.max(width, height);
            double scale = Math.min(areaScale, sideScale);
            if (scale < 1) {
                decoder.setTargetSize(Math.max(1, (int) (width * scale)), Math.max(1, (int) (height * scale)));
            }
        });
        Bitmap before = null;
        Bitmap after = null;
        boolean completed = false;
        try {
            before = previewCopy(output);
            renderer.render(output, chosen);
            after = previewCopy(output);
            completed = true;
            return new Rendered(before, after, output);
        } finally {
            if (!completed) {
                if (before != null) before.recycle();
                if (after != null) after.recycle();
                output.recycle();
            }
        }
    }

    private static Bitmap previewCopy(Bitmap photo) throws IOException {
        Bitmap scaled = M9Renderer.resizeTo(photo, PREVIEW_SIDE);
        if (scaled != photo) return scaled;
        Bitmap copy = photo.copy(Bitmap.Config.ARGB_8888, false);
        if (copy == null) throw new IOException("Could not create preview");
        return copy;
    }

    private void updateVignettePreview() {
        Rendered current = photo;
        if (current == null) return;
        int request = ++previewRequest;
        int amount = vignette;
        if (amount == 0) {
            shadedPreview = null;
            showPreview();
            return;
        }
        worker.execute(() -> {
            try {
                Bitmap shaded = DarkroomRenderer.withVignette(current.after, amount);
                runOnUiThread(() -> {
                    if (isDestroyed() || request != previewRequest) {
                        shaded.recycle();
                        return;
                    }
                    shadedPreview = shaded;
                    showPreview();
                });
            } catch (Exception | OutOfMemoryError error) {
                android.util.Log.e("LeicaMDarkroom", "Could not preview vignette", error);
                runOnUiThread(() -> {
                    if (!isDestroyed() && request == previewRequest && !busy) status.setText(R.string.preview_error);
                });
            }
        });
    }

    private void showPreview() {
        Bitmap visible = null;
        if (photo != null) {
            visible = showingOriginal ? photo.before : (shadedPreview == null ? photo.after : shadedPreview);
        }
        image.setImageBitmap(visible);
        welcome.setVisibility(photo == null && currentUri == null ? View.VISIBLE : View.GONE);
        compare.setText(showingOriginal ? R.string.after : R.string.before);
    }

    private void refresh(boolean active) {
        busy = active;
        progress.setVisibility(active ? View.VISIBLE : View.GONE);
        enable(select, !active);
        for (Button button : modeButtons) enable(button, !active);
        enable(vignetteBar, !active && photo != null);
        enable(compare, !active && photo != null);
        enable(save, !active && photo != null);
    }

    private void enable(View view, boolean enabled) {
        view.setEnabled(enabled);
        view.setAlpha(enabled ? 1f : 0.48f);
    }

    private void showError(int request, int message) {
        runOnUiThread(() -> {
            if (isDestroyed() || request != photoRequest) return;
            status.setText(message);
            refresh(false);
        });
    }

    private void savePhoto() {
        if (photo == null) return;
        Bitmap source = photo.output;
        int amount = vignette;
        int request = photoRequest;
        Mode chosen = mode;
        status.setText(R.string.saving);
        refresh(true);
        worker.execute(() -> {
            Bitmap adjusted = source;
            try {
                adjusted = DarkroomRenderer.withVignette(source, amount);
                saveToPhotos(adjusted, chosen);
                runOnUiThread(() -> {
                    if (isDestroyed()) return;
                    status.setText(getString(R.string.saved, ALBUM));
                    refresh(false);
                });
            } catch (OutOfMemoryError error) {
                showError(request, R.string.memory_error);
            } catch (Exception error) {
                android.util.Log.e("LeicaMDarkroom", "Could not save photo", error);
                showError(request, R.string.save_error);
            } finally {
                if (adjusted != source) adjusted.recycle();
            }
        });
    }

    private void saveToPhotos(Bitmap photo, Mode chosen) throws IOException {
        boolean png = photo.hasAlpha();
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.ROOT).format(new Date());
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, chosen.fileTag + "_" + stamp + (png ? ".png" : ".jpg"));
        values.put(MediaStore.Images.Media.MIME_TYPE, png ? "image/png" : "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + ALBUM);
        values.put(MediaStore.Images.Media.IS_PENDING, 1);
        ContentResolver resolver = getContentResolver();
        Uri destination = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (destination == null) throw new IOException("Photo collection is unavailable");
        boolean published = false;
        try {
            try (OutputStream stream = resolver.openOutputStream(destination)) {
                if (stream == null || !photo.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, 98, stream)) {
                    throw new IOException("Failed to encode the image");
                }
            }
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            if (resolver.update(destination, values, null, null) != 1) throw new IOException("Failed to publish photo");
            published = true;
        } finally {
            if (!published) resolver.delete(destination, null, null);
        }
    }

    @Override protected void onDestroy() {
        vignetteBar.removeCallbacks(previewUpdate);
        Rendered current = photo;
        worker.execute(() -> {
            if (current != null) current.output.recycle();
            renderer.close();
        });
        worker.shutdown();
        super.onDestroy();
    }
}
