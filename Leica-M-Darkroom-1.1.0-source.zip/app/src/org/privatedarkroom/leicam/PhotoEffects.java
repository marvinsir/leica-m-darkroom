package org.privatedarkroom.leicam;

final class PhotoEffects {
    private PhotoEffects() {}

    static void monochrome(int[] row) {
        // Publicly documented MONOPAN channel mix, normalized to preserve neutral whites.
        for (int x = 0; x < row.length; x++) {
            int pixel = row[x];
            int r = (pixel >>> 16) & 255;
            int g = (pixel >>> 8) & 255;
            int b = pixel & 255;
            int gray = (43708 * r + 41340 * g + 14617 * b + 49832) / 99665;
            row[x] = (pixel & 0xff000000) | gray * 0x010101;
        }
    }

    static final class Lut {
        private static final int SIDE = 17;
        private static final int R_STEP = SIDE * SIDE * 3;
        private static final int G_STEP = SIDE * 3;
        private static final int B_STEP = 3;
        private final byte[] bgr;
        private final int[] offsets = new int[256];
        private final float[] fractions = new float[256];

        Lut(byte[] bgr) {
            if (bgr.length != SIDE * SIDE * SIDE * 3) throw new IllegalArgumentException("Invalid 3D LUT size");
            this.bgr = bgr;
            for (int c = 0; c <= 255; c++) {
                float coordinate = c * ((SIDE - 1f) / 255f);
                offsets[c] = Math.min((int) coordinate, SIDE - 2);
                fractions[c] = coordinate - offsets[c];
            }
        }

        void apply(int[] row) {
            for (int x = 0; x < row.length; x++) {
                int p = row[x];
                int r = (p >>> 16) & 255;
                int g = (p >>> 8) & 255;
                int b = p & 255;
                int i = offsets[r] * R_STEP + offsets[g] * G_STEP + offsets[b] * B_STEP;
                float fr = fractions[r], fg = fractions[g], fb = fractions[b];
                row[x] = (p & 0xff000000) | (channel(i + 2, fr, fg, fb) << 16)
                        | (channel(i + 1, fr, fg, fb) << 8) | channel(i, fr, fg, fb);
            }
        }

        private int channel(int i, float fr, float fg, float fb) {
            float r0g0 = blue(i, fb);
            float r0g1 = blue(i + G_STEP, fb);
            float r1g0 = blue(i + R_STEP, fb);
            float r1g1 = blue(i + R_STEP + G_STEP, fb);
            float r0 = r0g0 + (r0g1 - r0g0) * fg;
            float r1 = r1g0 + (r1g1 - r1g0) * fg;
            return Math.round(r0 + (r1 - r0) * fr);
        }

        private float blue(int i, float amount) {
            int low = bgr[i] & 255;
            return low + ((bgr[i + B_STEP] & 255) - low) * amount;
        }
    }

    static final class Vignette {
        private final float strength;
        private final float[] radialX;
        private final float[] radialY;

        Vignette(int width, int height, int percent) {
            strength = 0.62f * percent / 100;
            radialX = radialAxis(width);
            radialY = radialAxis(height);
        }

        private static float[] radialAxis(int size) {
            float[] axis = new float[size];
            for (int i = 0; i < size; i++) {
                float position = size == 1 ? 0f : (2f * i / (size - 1)) - 1f;
                axis[i] = position * position / 2f;
            }
            return axis;
        }

        void apply(int y, int[] row) {
            if (strength == 0f) return;
            float vertical = radialY[y];
            for (int x = 0; x < row.length; x++) {
                float radius = radialX[x] + vertical;
                if (radius <= 0.12f) continue;
                float edge = (radius - 0.12f) / 0.88f;
                float gain = 1f - strength * edge * edge * (3f - 2f * edge);
                int p = row[x];
                int r = Math.round(((p >>> 16) & 255) * gain);
                int g = Math.round(((p >>> 8) & 255) * gain);
                int b = Math.round((p & 255) * gain);
                row[x] = (p & 0xff000000) | (r << 16) | (g << 8) | b;
            }
        }
    }
}
