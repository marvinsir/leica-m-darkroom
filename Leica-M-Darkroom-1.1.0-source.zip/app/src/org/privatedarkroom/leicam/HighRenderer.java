package org.privatedarkroom.leicam;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import java.io.IOException;
import java.nio.FloatBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtException;
import ai.onnxruntime.OrtSession;

final class HighRenderer {
    private HighRenderer() {}

    static void render(Bitmap original, AssetManager assets, boolean full)
            throws IOException, OrtException, InterruptedException {
        int width = original.getWidth(), height = original.getHeight();
        HighColorMap map = new HighColorMap(width, height, full ? 1120 : HighColorMap.WIDTH,
                full ? 864 : HighColorMap.HEIGHT);
        int gw = map.guideWidth(), gh = map.guideHeight();
        int[] pixels = new int[gw * gh];
        Bitmap guide = Bitmap.createScaledBitmap(original, gw, gh, true);
        try {
            guide.getPixels(pixels, 0, gw, 0, 0, gw, gh);
        } finally {
            if (guide != original) guide.recycle();
        }
        float[] input = map.inputs(pixels);
        float[] result = infer(input, assets, map, full ? "m9-high-full.onnx" : "m9-high-compact.onnx");
        map.setDelta(input, result);
        int[] row = new int[width];
        for (int y = 0; y < height; y++) {
            if (Thread.currentThread().isInterrupted()) throw new InterruptedException();
            original.getPixels(row, 0, width, 0, y, width, 1);
            map.renderRow(y, row, result);
            original.setPixels(row, 0, width, 0, y, width, 1);
        }
    }

    private static float[] infer(float[] input, AssetManager assets, HighColorMap map, String modelName)
            throws IOException, OrtException {
        OrtEnvironment env = OrtEnvironment.getEnvironment();
        int h = map.modelHeight, w = map.modelWidth;
        float[] mask = new float[h * w];
        Arrays.fill(mask, -128f / 127.5f);
        try (OrtSession.SessionOptions options = new OrtSession.SessionOptions()) {
            options.setIntraOpNumThreads(3);
            options.setInterOpNumThreads(1);
            options.setCPUArenaAllocator(false);
            options.setMemoryPatternOptimization(false);
            try (OrtSession session = env.createSession(M9Renderer.readModel(assets, modelName), options);
                 OnnxTensor rgb = OnnxTensor.createTensor(env, FloatBuffer.wrap(input), new long[]{1, 3, h, w});
                 OnnxTensor m = OnnxTensor.createTensor(env, FloatBuffer.wrap(mask), new long[]{1, 1, h, w})) {
                Map<String, OnnxTensor> inputs = new HashMap<>();
                inputs.put("rgb", rgb);
                inputs.put("mask", m);
                try (OrtSession.Result results = session.run(inputs)) {
                    OnnxTensor output = (OnnxTensor) results.get("out").orElseThrow(IllegalStateException::new);
                    long[] shape = output.getInfo().getShape();
                    if (!Arrays.equals(shape, new long[]{1, 3, h, w})) {
                        throw new IOException("M9 High 模型輸出尺寸不符");
                    }
                    return M9Renderer.copy(output);
                }
            }
        }
    }
}
