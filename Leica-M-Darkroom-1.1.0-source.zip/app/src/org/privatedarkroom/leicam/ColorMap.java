package org.privatedarkroom.leicam;

/** Applies the ONNX colour grid and residual using the graph's half-pixel interpolation. */
final class ColorMap {
    private final Plane grid;
    private final Plane residual;
    private final float[][] gridRow;
    private final float[][] residualRow;

    ColorMap(float[] coefficients, int gridW, int gridH, float[] residuals, int residualW,
             int residualH, int outputWidth, int outputHeight) {
        int intermediateW = Math.max(1, outputWidth / 16);
        int intermediateH = Math.max(1, outputHeight / 16);
        if (gridW != intermediateW || gridH != intermediateH) {
            coefficients = resizeGrid(coefficients, gridW, gridH, intermediateW, intermediateH);
        }
        grid = new Plane(coefficients, intermediateW, intermediateH, outputWidth, outputHeight);
        residual = new Plane(residuals, residualW, residualH, outputWidth, outputHeight);
        gridRow = new float[12][outputWidth];
        residualRow = new float[3][outputWidth];
    }

    private static float[] resizeGrid(float[] source, int w, int h, int outW, int outH) {
        Plane plane = new Plane(source, w, h, outW, outH);
        float[] output = new float[12 * outW * outH];
        float[][] row = new float[12][outW];
        for (int y = 0; y < outH; y++) {
            plane.sampleRow(y, row);
            for (int channel = 0; channel < row.length; channel++) {
                System.arraycopy(row[channel], 0, output, (channel * outH + y) * outW, outW);
            }
        }
        return output;
    }

    void renderRow(int y, int[] pixels) {
        grid.sampleRow(y, gridRow);
        residual.sampleRow(y, residualRow);
        for (int x = 0; x < pixels.length; x++) {
            int pixel = pixels[x];
            float r = ((pixel >>> 16) & 255) * (1f / 255f);
            float g = ((pixel >>> 8) & 255) * (1f / 255f);
            float b = (pixel & 255) * (1f / 255f);
            int out = pixel & 0xff000000;
            for (int channel = 0; channel < 3; channel++) {
                int i = channel * 3;
                float value = gridRow[i][x] * r + gridRow[i + 1][x] * g + gridRow[i + 2][x] * b;
                value += gridRow[9 + channel][x];
                value += Math.min(16f, Math.max(-16f, residualRow[channel][x]));
                int encoded = Math.round(Math.max(0f, Math.min(1f, value)) * 255f);
                out |= encoded << (16 - channel * 8);
            }
            pixels[x] = out;
        }
    }

    private static final class Axis {
        final int[] first;
        final int[] second;
        final float[] fraction;

        Axis(int source, int output) {
            first = new int[output];
            second = new int[output];
            fraction = new float[output];
            float ratio = (float) source / output;
            for (int i = 0; i < output; i++) {
                float position = Math.max(0f, (i + 0.5f) * ratio - 0.5f);
                int lower = Math.min((int) position, source - 1);
                first[i] = lower;
                second[i] = Math.min(lower + 1, source - 1);
                fraction[i] = position - lower;
            }
        }
    }

    private static final class Plane {
        private final float[] data;
        private final int width;
        private final int planeSize;
        private final Axis x;
        private final Axis y;

        Plane(float[] data, int width, int height, int outWidth, int outHeight) {
            this.data = data;
            this.width = width;
            planeSize = width * height;
            x = new Axis(width, outWidth);
            y = new Axis(height, outHeight);
        }

        void sampleRow(int row, float[][] target) {
            int topOffset = y.first[row] * width;
            int lowerOffset = y.second[row] * width;
            float dy = y.fraction[row];
            for (int c = 0; c < target.length; c++) {
                int plane = c * planeSize;
                float[] channel = target[c];
                for (int col = 0; col < channel.length; col++) {
                    int left = x.first[col];
                    int right = x.second[col];
                    float dx = x.fraction[col];
                    float top = data[plane + topOffset + left] * (1f - dx)
                            + data[plane + topOffset + right] * dx;
                    float bottom = data[plane + lowerOffset + left] * (1f - dx)
                            + data[plane + lowerOffset + right] * dx;
                    channel[col] = top * (1f - dy) + bottom * dy;
                }
            }
        }
    }
}
