package org.privatedarkroom.leicam;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import java.io.IOException;

final class DarkroomRenderer implements AutoCloseable {
    enum Mode {
        QUICK(R.string.m9_fast, R.string.tab_fast, "M9-Fast"),
        HIGH(R.string.m9_high, R.string.tab_high, "M9-High"),
        FULL(R.string.m9_full, R.string.tab_full, "M9-Full"),
        COLOR(R.string.m9_lut, R.string.tab_lut, "M9-LUT"),
        MONO(R.string.monochrome, R.string.tab_mono, "Mono");

        final int label;
        final int shortLabel;
        final String fileTag;

        Mode(int label, int shortLabel, String fileTag) {
            this.label = label;
            this.shortLabel = shortLabel;
            this.fileTag = fileTag;
        }
    }

    private final AssetManager assets;
    private final M9Renderer quick;
    private PhotoEffects.Lut previewLut;
    private PhotoEffects.Lut snapshotLut;

    DarkroomRenderer(AssetManager assets) {
        this.assets = assets;
        quick = new M9Renderer(assets);
    }

    void render(Bitmap photo, Mode mode) throws Exception {
        switch (mode) {
            case QUICK:
                quick.render(photo);
                break;
            case HIGH:
                HighRenderer.render(photo, assets, false);
                break;
            case FULL:
                HighRenderer.render(photo, assets, true);
                if (snapshotLut == null) snapshotLut = loadLut("m9-snapshot-daylight.lut");
                applyRows(photo, (y, row) -> snapshotLut.apply(row));
                break;
            case COLOR:
                if (previewLut == null) previewLut = loadLut("m9-preview-daylight.lut");
                applyRows(photo, (y, row) -> previewLut.apply(row));
                break;
            case MONO:
                applyRows(photo, (y, row) -> PhotoEffects.monochrome(row));
                break;
        }
    }

    private PhotoEffects.Lut loadLut(String name) throws IOException {
        return new PhotoEffects.Lut(M9Renderer.readModel(assets, name));
    }

    static Bitmap withVignette(Bitmap source, int amount) throws IOException, InterruptedException {
        if (amount == 0) return source;
        Bitmap shaded = source.copy(Bitmap.Config.ARGB_8888, true);
        if (shaded == null) throw new IOException("Could not create vignette bitmap");
        boolean complete = false;
        try {
            PhotoEffects.Vignette effect = new PhotoEffects.Vignette(shaded.getWidth(), shaded.getHeight(), amount);
            applyRows(shaded, effect::apply);
            complete = true;
            return shaded;
        } finally {
            if (!complete) shaded.recycle();
        }
    }

    private interface RowEffect {
        void apply(int y, int[] row);
    }

    private static void applyRows(Bitmap photo, RowEffect effect) throws InterruptedException {
        int width = photo.getWidth();
        int[] row = new int[width];
        for (int y = 0; y < photo.getHeight(); y++) {
            if (Thread.currentThread().isInterrupted()) throw new InterruptedException();
            photo.getPixels(row, 0, width, 0, y, width, 1);
            effect.apply(y, row);
            photo.setPixels(row, 0, width, 0, y, width, 1);
        }
    }

    @Override public void close() {
        quick.close();
    }
}
