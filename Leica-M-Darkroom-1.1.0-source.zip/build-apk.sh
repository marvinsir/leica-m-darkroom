#!/usr/bin/env bash
set -euo pipefail
work="$(cd "$(dirname "$0")" && pwd)"
tools="${ANDROID_BUILD_TOOLS:-$work/../apk-tools/android-15}"
base="${DARKROOM_TOOLCHAIN:-$work/../leica-m9-build}"
export JAVA_HOME="${JAVA_HOME:-$base/jdk}"
export PATH="$JAVA_HOME/bin:$PATH"
sdk="${ANDROID_JAR:-$base/sdk/android-36/android.jar}"
app="$work/app"
stage="$work/out"
delivery="$work/../delivery"
ort="$base/ort"
if [ -n "${ORT_AAR:-}" ]; then
    ort="$stage/ort"
    mkdir -p "$ort"
    unzip -oq "$ORT_AAR" 'classes.jar' 'jni/arm64-v8a/*.so' -d "$ort"
fi
mkdir -p "$stage"/{classes,apk/lib/arm64-v8a,dex,signing} "$delivery"

"$tools/aapt2" compile --dir "$app/res" -o "$stage/resources.zip"
"$tools/aapt2" link -I "$sdk" --manifest "$app/AndroidManifest.xml" --java "$stage" -A "$app/assets" -o "$stage/app-base.apk" "$stage/resources.zip"
"$JAVA_HOME/bin/javac" -encoding UTF-8 --release 8 -classpath "$sdk:$ort/classes.jar" -d "$stage/classes" "$stage/org/privatedarkroom/leicam/R.java" "$app"/src/org/privatedarkroom/leicam/*.java
"$JAVA_HOME/bin/jar" cf "$stage/our-classes.jar" -C "$stage/classes" .
"$tools/d8" --release --min-api 29 --lib "$sdk" --output "$stage/dex" "$stage/our-classes.jar" "$ort/classes.jar"
cp "$stage/dex/classes.dex" "$stage/apk/"
cp "$ort/jni/arm64-v8a/"*.so "$stage/apk/lib/arm64-v8a/"
cp "$stage/app-base.apk" "$stage/app-unsigned.apk"
(
    cd "$stage/apk"
    zip -q -r ../app-unsigned.apk classes.dex lib
)
"$tools/zipalign" -P 16 -f 4 "$stage/app-unsigned.apk" "$stage/app-aligned.apk"
if [ ! -f "$stage/signing/signer.p12" ]; then
    (
        umask 077
        openssl rand -hex 24 > "$stage/signing/password"
        keytool -genkeypair -storetype PKCS12 -keystore "$stage/signing/signer.p12" -storepass:file "$stage/signing/password" -alias leica-m-darkroom -keyalg RSA -keysize 3072 -validity 10000 -dname "CN=Leica M Darkroom Personal Build"
    )
fi
version_name=$(sed -n 's/.*android:versionName="\([^"]*\)".*/\1/p' "$app/AndroidManifest.xml")
apk="$delivery/Leica-M-Darkroom-$version_name-arm64.apk"
"$tools/apksigner" sign --ks "$stage/signing/signer.p12" --ks-key-alias leica-m-darkroom --ks-pass "file:$stage/signing/password" --v2-signing-enabled true --v3-signing-enabled true --v4-signing-enabled false --out "$apk" "$stage/app-aligned.apk"
"$tools/apksigner" verify --verbose "$apk"
"$tools/apksigner" verify --min-sdk-version 33 --max-sdk-version 33 "$apk"
"$tools/zipalign" -P 16 -c 4 "$apk"
"$tools/aapt" dump badging "$apk" | grep -E "^package:|^sdkVersion:|^targetSdkVersion:|^application-label:|^native-code:|^launchable-activity:|^uses-permission"
sha256sum "$apk"
ls -lh "$apk"
