"""Prepare the original-resolution ONNX and two fixed daylight 3D LUTs."""
from pathlib import Path
import struct
import sys

import onnx
from onnx import numpy_helper

source = Path(sys.argv[1])
destination = Path(__file__).resolve().parent / "app/assets"
model = onnx.load(source / "m9fb_styletrans_high.onnx", load_external_data=False)
graph = model.graph
conv, clip, truncate = graph.node[-3:]
assert conv.op_type == "Conv" and clip.op_type == "Clip" and truncate.op_type == "Slice"
assert list(conv.output) == list(clip.input[:1])
assert list(clip.output) == list(truncate.input[:1])
weights = {item.name: item for item in graph.initializer}
assert [numpy_helper.to_array(weights[name]).tolist() for name in truncate.input[1:]] == [[0], [3], [1], [1]]
for name in conv.input[1:]:
    tensor = weights[name]
    tensor.CopyFrom(numpy_helper.from_array(numpy_helper.to_array(tensor)[:3].copy(), name))
clip.output[0] = truncate.output[0]
del graph.node[-1]
still_used = {name for node in graph.node for name in node.input}
for i in reversed(range(len(graph.initializer))):
    if graph.initializer[i].name not in still_used:
        del graph.initializer[i]
del graph.value_info[:]
onnx.checker.check_model(model, full_check=True)
onnx.save_model(model, destination / "m9-high-full.onnx")

for kind in ("preview", "snapshot"):
    raw = (source / f"leica_filter_param_m9_{kind}.bin").read_bytes()
    assert b"aiscene-lux-cct" in raw[:0x120]
    scenes, = struct.unpack_from("<H", raw)
    _, offset, side, _ = struct.unpack_from("<4H", raw, 2 * (1 + scenes))
    assert side == 17
    # OffLineM9's common scene at lux index 275 and 5500 K selects table 5 in both files.
    size = side ** 3 * 3
    lut = raw[offset + 5 * size:offset + 6 * size]
    assert len(lut) == size
    (destination / f"m9-{kind}-daylight.lut").write_bytes(lut)
