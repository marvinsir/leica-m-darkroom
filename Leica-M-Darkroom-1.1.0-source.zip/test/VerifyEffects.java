package org.privatedarkroom.leicam;

import java.io.DataInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

final class VerifyEffects {
    public static void main(String[] args) throws Exception {
        for (int i = 0; i < args.length; i += 2) {
            PhotoEffects.Lut lut = new PhotoEffects.Lut(Files.readAllBytes(Paths.get(args[i])));
            try (DataInputStream in = new DataInputStream(Files.newInputStream(Paths.get(args[i + 1])))) {
                int length = in.readInt();
                int[] row = new int[length];
                for (int x = 0; x < length; x++) row[x] = in.readInt();
                lut.apply(row);
                int maxError = 0;
                for (int pixel : row) {
                    int expected = in.readInt();
                    if (pixel >>> 24 != expected >>> 24) throw new AssertionError("LUT alpha");
                    for (int shift : new int[] {0, 8, 16}) {
                        int error = Math.abs(((pixel >>> shift) & 255) - ((expected >>> shift) & 255));
                        maxError = Math.max(maxError, error);
                    }
                }
                if (maxError > 1) throw new AssertionError("LUT interpolation error: " + maxError);
                System.out.println(args[i] + " LUT matches reference within " + maxError + "/255");
            }
        }

        int[] rgb = {0x22ff0000, 0x44ffFFff, 0x6600ff00, 0x880000ff, 0xa0000000, 0xaf787878};
        int[] expected = {0x22707070, 0x44ffffff, 0x666a6a6a, 0x88252525, 0xa0000000, 0xaf787878};
        PhotoEffects.monochrome(rgb);
        if (!Arrays.equals(rgb, expected)) throw new AssertionError("Monochrome channel mixing or alpha");
        for (int[] bounds : new int[][] {{5, 7}, {7, 5}, {1, 9}, {1, 1}}) {
            int width = bounds[0], height = bounds[1];
            PhotoEffects.Vignette off = new PhotoEffects.Vignette(width, height, 0);
            PhotoEffects.Vignette mid = new PhotoEffects.Vignette(width, height, 50);
            PhotoEffects.Vignette full = new PhotoEffects.Vignette(width, height, 100);
            final int gray = 0x76c8c8c8;
            int[] firstRow = new int[width];
            int[] lastRow = new int[width];
            for (int y = 0; y < height; y++) {
                int[] row = new int[width];
                Arrays.fill(row, gray);
                off.apply(y, row);
                for (int pixel : row) if (pixel != gray) throw new AssertionError("0% vignette");
                int[] moderate = row.clone();
                mid.apply(y, moderate);
                full.apply(y, row);
                for (int x = 0; x < width; x++) {
                    int pixel = row[x];
                    if (pixel >>> 24 != gray >>> 24) throw new AssertionError("Vignette alpha");
                    if ((pixel & 255) > (moderate[x] & 255) || (moderate[x] & 255) > (gray & 255)) {
                        throw new AssertionError("Vignette strength must be monotonic");
                    }
                    if (pixel != row[width - x - 1]) throw new AssertionError("Vignette symmetry");
                }
                if (y == height / 2 && row[width / 2] != gray) throw new AssertionError("Vignette center");
                if (y == 0) firstRow = row;
                if (y == height - 1) lastRow = row;
            }
            if (!Arrays.equals(firstRow, lastRow)) throw new AssertionError("Vertical symmetry");
            if (width > 1 && firstRow[0] >= gray) throw new AssertionError("Vignette corners");
        }
        System.out.println("MONOPAN and 0% / 50% / 100% vignette verified");
    }
}
